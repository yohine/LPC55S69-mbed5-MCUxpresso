#ifdef PSA_CRYPTO_SECURE
#include "crypto_struct_spe.h"
#else
#include "crypto_struct_ipc.h"
#endif

